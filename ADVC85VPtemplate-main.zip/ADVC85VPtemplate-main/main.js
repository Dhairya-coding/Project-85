//Create a reference for canvas 
canvas = document.getElementById("MyCanvas");
ctx = canvas.getContext("2d");

//Give specific height and width to the car image
car_width = 75;
car_height = 100;

background_image = "parkingLot.jpg";
greencar_image = "car2.png";

//Set initial position for a car image.

car_x =5;
car_y =225;

function add() {
    new_bg = new Image();
    new_bg.onload = upload_bg;
    new_bg.src=background_image;

    rover_bg = new Image();
    rover_bg.onload = upload_green_car;
    rover_bg.src=greencar_image;
}

function upload_bg() {
    ctx.drawImage(new_bg,0,0,canvas.width,canvas.height);
}

function upload_green_car() {
    ctx.drawImage(rover_bg,car_x,car_y,car_width,car_height);
}


window.addEventListener("keydown", my_keydown);

function my_keydown(e)
{
	keyPressed = e.keyCode;
	console.log(keyPressed);
		if(keyPressed == '38')
		{
			up();
			console.log("up");
		}
	
		if(keyPressed == '40')
		{
			down();
			console.log("down");
		}
		
		if(keyPressed == '37')
		{
			left();
			console.log("left");
		}
	
		if(keyPressed == '39')
		{
			right();
			console.log("right");
		}
		
		
}

function up() {
    if(car_y>=0) {
     car_y = car_y -10;
     upload_bg();
     upload_green_car();
    }
}

function down() {
    if(car_y<=600) {
     car_y = car_y +10;
     upload_bg();
     upload_green_car();
    }
}

function left() {
    if(car_x>=0) {
     car_x = car_x -10;
     upload_bg();
     upload_green_car();
    }
}

function right() {
    if(car_x<=800) {
     car_x = car_x +10;
     upload_bg();
     upload_green_car();
    }
}